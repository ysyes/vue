import Vue from 'vue'
import Router from 'vue-router'

import Login from '@/components/Login'
/*首页*/
import Home from '@/components/home/home'
/*用户*/
import User from '@/components/user/User'
/*测试*/
import Test from '@/components/nav1/Test'
import Test2 from '@/components/nav1/Test2'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Login',
      component: Login,
      hidden: true
    },
    {
      path: '/',
      name: 'Home',
      iconClass:'el-icon-message',
      component: Home,
      children: [
        { path: '/user', component: User, name: '用户管理' },
      ]
    },
    {
      path: '/',
      name: '录入管理',
      iconClass:'el-icon-message',
      component: Home,
      children: [
        { path: '/test', component: Test, name: '测试1' },
        { path: '/test2', component: Test2, name: '测试2' },
      ]
    }
  ]
})
