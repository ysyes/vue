export default {
    login:'/v1/user/new/login',
    live: {
        list: '/live/web', //直播列表
        videoUrl(id,urlStatus){return '/live/url/web/'+id+'/'+urlStatus}, //获取直播地址
    },
    pwd: {
        sendEmail: '/manage/user/sendEmail',
        resetPwd: '/manage/user/passwordReset'
    }
}
