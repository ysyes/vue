<template>
    <div>用户管理</div>
</template>

<script>
    export default {
        name: "User"
    }
</script>

<style scoped>

</style>
