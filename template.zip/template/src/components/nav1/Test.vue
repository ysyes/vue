<template>
    <div>测试1</div>
</template>

<script>
    export default {
        name: "Test"
    }
</script>

<style scoped>

</style>
